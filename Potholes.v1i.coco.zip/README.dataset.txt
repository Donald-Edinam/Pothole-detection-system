# Potholes > 2024-07-01 2:47pm
https://universe.roboflow.com/knust-a6ppt/potholes-esdiw

Provided by a Roboflow user
License: CC BY 4.0

